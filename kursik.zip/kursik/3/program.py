pcs = 12
s = 'W magazynie {} sztuk.'.format(pcs)
print(s)