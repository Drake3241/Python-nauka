print('Program do porownywania liczby')
a = float(input('Wprowadz 1 liczbe: '))
b = float(input('Wprowadz 2 liczbe: '))
if a == b:
    print("Zgadza sie")
else:
    print("Nie zgadza sie")

print("Koniec programu ziomeczku")