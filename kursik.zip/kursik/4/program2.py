a = True

if a == True:
    print('Warunek spelniony')

