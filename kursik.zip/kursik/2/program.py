# to jest testowy komentarz
# do kazdej lini trzeba hasz
a = 1
print(a) #to jest funkcja print()

# za pomoca skrotu w visual studio ctrl+/ mozna zrobic komentarz na wiele lini poprzez oznaczenie
# za pomoca skrotu w visual studio ctrl+/ mozna zrobic komentarz na wiele lini poprzez oznaczenie
# za pomoca skrotu w visual studio ctrl+/ mozna zrobic komentarz na wiele lini poprzez oznaczenie
# za pomoca skrotu w visual studio ctrl+/ mozna zrobic komentarz na wiele lini poprzez oznaczenie